<?php
    $host = "mysql.idhostinger.com";
    $user = "u358555650_gba";
    $pass = "kurangdari=1";
    $db = "u358555650_soal";
    
    $con = mysqli_connect($host, $user, $pass, $db);
?>