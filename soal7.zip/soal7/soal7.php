<!DOCTYPE html>
<html>
    
<head>
    
    <?php 
    include("koneksi.php");
    $result = mysqli_query($con, 'SELECT c.id AS id, c.name AS name, COUNT( p.category_id ) AS Jumlah_product FROM product_categories c JOIN products p ON c.id = p.category_id GROUP BY category_id');
                		
		while ($data = mysqli_fetch_array ($result)){
			$id[] = $data['id'];
			$name[] = $data['name'];
			$jumlah[] = $data['Jumlah_product'];
	    }
    ?>
<style>
table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

td, th {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;
}

tr:nth-child(even) {
    background-color: #dddddd;
}
</style>
</head>
<body>

<h2>SOAL NOOR 7</h2>

<table>
  <tr>
    <th>ID</th>
    <th>Name</th>
    <th>Jumlah_produk</th>
  </tr>
  <?php for($i=0; $i<sizeof($id); $i++){?> 
  <tr>
    <td><?php echo $id[$i] ?></td>
    <td><?php echo $name[$i] ?></td>
    <td><?php echo $jumlah[$i] ?></td>
  </tr>
  <?php } ?>
</table>

</body>
</html>
